# ai-stack – lokale KI-Arbeitsumgebung (NVIDIA RTX, 16 GB+ VRAM)

| Dienst | Zweck | Adresse (Host) | Adresse im Docker-Netz `ai-net` |
|---|---|---|---|
| ollama | LLM-Serving (Qwen 3 / Qwen 2.5-VL, LoRA via Modelfile) | http://localhost:11434 | http://ollama:11434 |
| vllm *(Profil `vllm`)* | OpenAI-API, AWQ-Modell, LoRA-Hot-Loading | http://localhost:8000 | http://vllm:8000 |
| open-webui | Chat-Oberfläche, an Ollama, ComfyUI und TTS angebunden | http://localhost:3000 | http://open-webui:8080 |
| comfyui | Bild/Video (Z-Image Turbo, Wan 2.2), Manager, VHS, GGUF, KJNodes | http://localhost:8188 | http://comfyui:8188 |
| tts | Parler-TTS mini (Stimme per Textbeschreibung), OpenAI-kompatibel | http://localhost:8020 | http://tts:8020 |
| agent *(Profil `agent`)* | Browser Use + Playwright/Chromium, gesteuert von einem VLM | – | – |

Alle Ports sind nur an `127.0.0.1` gebunden, also von aussen nicht erreichbar.

## Start

```bash
cp -r ai-stack ~/ai-stack && cd ~/ai-stack
chmod +x scripts/*.sh
./scripts/setup.sh          # installiert Toolkit, baut Images, lädt Modelle, testet
```

Danach im Alltag:

```bash
docker compose up -d                       # alles starten
docker compose ps                          # Status
./scripts/check.sh                         # GPU- und Netzwerk-Check
docker compose run --rm agent "Öffne http://comfyui:8188 und beschreibe den Workflow"
docker compose --profile vllm up -d vllm   # vLLM statt Ollama (vorher Ollama-Modell entladen)
docker compose down                        # alles stoppen (Daten bleiben in ./data und den Volumes)
```

## 16 GB VRAM: was gleichzeitig geht

Alle Dienste teilen sich eine GPU. Damit es nicht zu «out of memory» kommt:

- **Ollama** wirft Modelle nach 2 Minuten ohne Anfrage aus dem VRAM (`OLLAMA_KEEP_ALIVE`) und hält nur eines geladen. Der KV-Cache ist auf q8 gestellt.
- **ComfyUI** lagert Modelle automatisch in den RAM aus und hält 1 GB Reserve frei (`--reserve-vram 1.0`). Für Wan 2.2 14B die GGUF-Variante (Q4) nehmen, das 5B-Modell läuft direkt.
- **TTS** braucht rund 2 GB. Mit `TTS_DEVICE=cpu` in `.env` läuft es ohne GPU, nur langsamer.
- **vLLM** reserviert 85 % des VRAM fest. Nur einschalten, wenn ComfyUI gerade nichts rechnet.
- **Qwen 3 32B** (Q4, rund 20 GB) passt nicht ganz in 16 GB. Ollama verteilt es auf GPU und CPU, das ist deutlich langsamer. Für flüssiges Arbeiten `qwen3:14b` verwenden, für Bilder und Screenshots `qwen2.5vl:7b`.
- Faustregel: entweder ein grosses LLM **oder** Video-Generierung, nicht beides gleichzeitig.

RAM: mindestens 32 GB, für Wan 14B besser 64 GB.

## LoRA-Adapter

- **LLM (Ollama):** Adapter nach `./loras/` legen, `loras/Modelfile.example` anpassen, dann
  `docker exec ollama ollama create qwen3-mein-lora -f /loras/Modelfile.example`
- **LLM (vLLM):** Adapter-Ordner nach `./loras/<name>/`, dann zur Laufzeit laden:
  `curl localhost:8000/v1/load_lora_adapter -H 'Content-Type: application/json' -d '{"lora_name":"<name>","lora_path":"/loras/<name>"}'`
- **Bild (ComfyUI):** `.safetensors` nach `data/comfyui/models/loras/`, im Workflow den Node «LoraLoaderModelOnly» verwenden.

## Open WebUI anbinden

- **LLM:** läuft automatisch über `OLLAMA_BASE_URL`.
- **Bilder:** Admin → Einstellungen → Bilder → ComfyUI ist voreingestellt. Dort einen im ComfyUI exportierten Workflow (API-Format) hochladen und die Prompt-Node zuordnen.
- **Sprache:** Admin → Einstellungen → Audio → TTS «OpenAI», URL `http://tts:8020/v1`. Als Stimme `coach`, `calm` oder `male` eintragen.

## Browser-Agent

`agent/run_agent.py` nutzt Browser Use 1.x mit einem lokalen Chromium. Das Modell wird über die OpenAI-kompatible API angesprochen (`LLM_BASE_URL`, `LLM_MODEL`).

- Standard ist `qwen2.5vl:7b` über Ollama. Kleine lokale VLMs scheitern bei längeren Abläufen öfter. Für zuverlässigere Ergebnisse `LLM_BASE_URL` auf vLLM oder eine externe API setzen.
- Der Agent darf nur die Hosts in `ALLOWED_DOMAINS` öffnen (Standard: die eigenen Dienste). Seiten mit Logins oder fremde Websites bitte bewusst freigeben und keine Passwörter in Aufgaben schreiben.
- Ergebnisse und Dateien landen in `data/agent/`.

## Ordner

```
docker-compose.yml   .env.example   README.md
comfyui/  Dockerfile, entrypoint.sh            data/comfyui/{models,output,input,user}
tts/      Dockerfile, app.py                   data/tts
agent/    Dockerfile, run_agent.py, tasks/     data/agent
loras/    Modelfile.example
scripts/  setup.sh, download_models.sh, check.sh
```
