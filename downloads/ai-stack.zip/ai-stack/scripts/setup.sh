#!/usr/bin/env bash
# Einmaliges Setup der KI-Arbeitsumgebung (Ubuntu 22.04/24.04, NVIDIA-GPU mit 16 GB+ VRAM).
# Aufruf aus dem Projektordner:  ./scripts/setup.sh
set -euo pipefail
cd "$(dirname "$0")/.."
say() { printf '\n\033[1;32m==> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31mFEHLER: %s\033[0m\n' "$*"; exit 1; }

say "1/7 GPU und Treiber prüfen"
command -v nvidia-smi >/dev/null || die "nvidia-smi fehlt. Zuerst den NVIDIA-Treiber installieren (sudo ubuntu-drivers install) und neu starten."
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader
VRAM=$(nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits | head -1)
[ "$VRAM" -ge 15000 ] || echo "Warnung: nur ${VRAM} MiB VRAM. Kleinere Modelle verwenden."

say "2/7 Docker und NVIDIA Container Toolkit"
if ! command -v docker >/dev/null; then
  curl -fsSL https://get.docker.com | sudo sh
  sudo usermod -aG docker "$USER"
  echo "Docker installiert. Einmal ab- und wieder anmelden (Gruppe 'docker'), dann das Skript erneut starten."; exit 0
fi
if ! docker info 2>/dev/null | grep -qi nvidia; then
  curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor --yes -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
  curl -fsSL https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list \
    | sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' \
    | sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list >/dev/null
  sudo apt-get update && sudo apt-get install -y nvidia-container-toolkit
  sudo nvidia-ctk runtime configure --runtime=docker
  sudo systemctl restart docker
fi
docker run --rm --gpus all nvidia/cuda:12.8.1-base-ubuntu24.04 nvidia-smi -L || die "GPU im Container nicht sichtbar."

say "3/7 Ordner und .env"
mkdir -p data/comfyui/{models,output,input,user,custom_nodes_extra} data/tts data/agent loras
[ -f .env ] || cp .env.example .env

say "4/7 Images bauen (dauert beim ersten Mal 10–20 Minuten)"
docker compose build comfyui tts
docker compose --profile agent build agent

say "5/7 Dienste starten"
docker compose up -d ollama open-webui comfyui tts
until docker exec ollama ollama list >/dev/null 2>&1; do sleep 2; done

say "6/7 LLMs laden (Ollama)"
# shellcheck disable=SC1091
source .env
for m in ${OLLAMA_MODELS:-qwen3:14b qwen2.5vl:7b}; do
  echo "-> $m"; docker exec ollama ollama pull "$m"
done

say "7/7 ComfyUI-Modelle laden"
./scripts/download_models.sh "${COMFY_MODELS:-zimage wan5b}"
docker compose restart comfyui

say "Smoke-Tests"
./scripts/check.sh || true
cat <<EOF

Fertig. Oberflächen (nur lokal erreichbar):
  Open WebUI   http://localhost:3000   (erster Login legt das Admin-Konto an)
  ComfyUI      http://localhost:8188
  Ollama API   http://localhost:11434
  TTS          http://localhost:8020/docs
Browser-Agent: docker compose run --rm agent --file tasks/beispiel.txt
EOF
