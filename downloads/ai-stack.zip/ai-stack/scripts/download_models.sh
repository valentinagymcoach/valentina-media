#!/usr/bin/env bash
# Lädt ComfyUI-Modelle, die auf 16 GB VRAM laufen.
# Aufruf: ./scripts/download_models.sh "zimage wan5b"     (Pakete: zimage, wan5b, wan14b-gguf)
set -euo pipefail
cd "$(dirname "$0")/.."
M=data/comfyui/models
mkdir -p $M/{diffusion_models,text_encoders,vae,loras,unet}
dl() { [ -s "$1" ] && { echo "vorhanden: $1"; return; }; echo "lade: $1"; wget -q --show-progress -c -O "$1.part" "$2" && mv "$1.part" "$1"; }
ZI=https://huggingface.co/Comfy-Org/z_image_turbo/resolve/main/split_files
WAN=https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files

for pkg in ${1:-zimage wan5b}; do
  case $pkg in
    zimage)   # Bild: Z-Image Turbo (8 Schritte, ~12 GB, Text-Encoder wird ausgelagert)
      dl $M/diffusion_models/z_image_turbo_bf16.safetensors $ZI/diffusion_models/z_image_turbo_bf16.safetensors
      dl $M/text_encoders/qwen_3_4b.safetensors            $ZI/text_encoders/qwen_3_4b.safetensors
      dl $M/vae/ae.safetensors                              $ZI/vae/ae.safetensors ;;
    wan5b)    # Video: Wan 2.2 TI2V 5B (Text/Bild->Video, 720p, passt in 16 GB)
      dl $M/diffusion_models/wan2.2_ti2v_5B_fp16.safetensors $WAN/diffusion_models/wan2.2_ti2v_5B_fp16.safetensors
      dl $M/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors $WAN/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors
      dl $M/vae/wan2.2_vae.safetensors                        $WAN/vae/wan2.2_vae.safetensors ;;
    wan14b-gguf)  # Video: Wan 2.2 I2V 14B als GGUF Q4 (bessere Qualität, langsamer; Node "Unet Loader (GGUF)")
      echo "GGUF-Dateien (HighNoise + LowNoise, je Q4_K_M) aus https://huggingface.co/QuantStack/Wan2.2-I2V-A14B-GGUF"
      echo "nach $M/unet/ legen; dazu umt5 + wan_2.1_vae:"
      dl $M/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors $WAN/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors
      dl $M/vae/wan_2.1_vae.safetensors                       $WAN/vae/wan_2.1_vae.safetensors ;;
    *) echo "unbekanntes Paket: $pkg" ;;
  esac
done
echo "Eigene LoRAs (z. B. für Z-Image) nach $M/loras/ kopieren."
