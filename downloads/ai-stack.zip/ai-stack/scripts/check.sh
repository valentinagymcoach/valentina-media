#!/usr/bin/env bash
# Prüft, ob alle Dienste laufen und die GPU nutzen.
cd "$(dirname "$0")/.."
ok() { printf '  \033[32mOK\033[0m   %s\n' "$*"; }; bad() { printf '  \033[31mFEHLT\033[0m %s\n' "$*"; }
echo "Dienste:"
curl -sf localhost:11434/api/tags >/dev/null && ok "Ollama" || bad "Ollama"
curl -sf localhost:3000/health   >/dev/null && ok "Open WebUI" || bad "Open WebUI"
curl -sf localhost:8188/system_stats >/dev/null && ok "ComfyUI" || bad "ComfyUI"
curl -sf localhost:8020/health   >/dev/null && ok "TTS" || bad "TTS"
echo "GPU in den Containern:"
for c in ollama comfyui tts; do
  docker exec "$c" nvidia-smi -L >/dev/null 2>&1 && ok "$c sieht die GPU" || bad "$c ohne GPU"
done
curl -s localhost:8188/system_stats | python3 -c "import sys,json;d=json.load(sys.stdin)['devices'][0];print(f\"  ComfyUI-Gerät: {d['name']}  VRAM frei: {d['vram_free']//2**20} MiB\")" 2>/dev/null
echo "Netzwerk (Open WebUI -> Ollama/ComfyUI/TTS):"
docker exec open-webui sh -c 'curl -sf http://ollama:11434/api/tags >/dev/null && echo "  ollama erreichbar"; curl -sf http://comfyui:8188/system_stats >/dev/null && echo "  comfyui erreichbar"; curl -sf http://tts:8020/health >/dev/null && echo "  tts erreichbar"'
echo "Kurzer LLM-Test:"
M=$(curl -s localhost:11434/api/tags | python3 -c "import sys,json;m=json.load(sys.stdin)['models'];print(m[0]['name'] if m else '')")
[ -n "$M" ] && curl -s localhost:11434/api/generate -d "{\"model\":\"$M\",\"prompt\":\"Sag Hallo in einem Wort.\",\"stream\":false}" \
  | python3 -c "import sys,json;r=json.load(sys.stdin);print('  ',r.get('response','').strip()[:80], f\"({r.get('eval_count',0)/(r.get('eval_duration',1)/1e9):.0f} tok/s)\")"
