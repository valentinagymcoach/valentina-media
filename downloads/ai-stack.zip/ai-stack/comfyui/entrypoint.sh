#!/bin/bash
set -e
cd /opt/ComfyUI
# zusätzliche Nodes aus dem Volume (z. B. über den Manager installiert) verlinken
for d in /opt/ComfyUI/custom_nodes_extra/*/; do
  [ -d "$d" ] || continue
  n=$(basename "$d")
  [ -e "custom_nodes/$n" ] || ln -s "$d" "custom_nodes/$n"
  [ -f "$d/requirements.txt" ] && pip install -q -r "$d/requirements.txt" || true
done
python -c "import torch;print('CUDA:', torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else '-')"
exec python main.py ${COMFY_ARGS}
